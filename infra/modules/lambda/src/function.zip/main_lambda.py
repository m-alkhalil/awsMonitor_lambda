import boto3
import json

def lambda_handler(event, context):
    print("🔍 Event received by Lambda:")
    print(json.dumps(event, indent=2))

    ec2 = boto3.client("ec2")
